#!/bin/bash

/opt/McAfee/ens/tp/init/mfetpd-control.sh stop
echo ""
/opt/McAfee/ens/esp/init/mfeespd-control.sh stop
