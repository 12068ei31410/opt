#!/bin/bash

hammer content-view publish --id 2 --organization "RDT&E" --async
