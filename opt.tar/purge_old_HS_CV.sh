#!/bin/bash

hammer content-view purge --organization "RDT&E" --name "RDT&E Hosting Services" --count 4
