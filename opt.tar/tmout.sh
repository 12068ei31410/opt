#!/bin/bash

TMOUT=900
readonly TMOUT
export TMOUT
