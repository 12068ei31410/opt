#!/bin/bash

hammer content-view purge --organization "RDT&E" --name "RDT&E Core Services" --count 4
