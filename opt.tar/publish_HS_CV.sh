#!/bin/bash

hammer content-view publish --id 3 --organization "RDT&E" --async
